from django.utils.deprecation import MiddlewareMixin
from django.shortcuts import redirect

from app01 import models


class Auth(MiddlewareMixin):
    white_list = [
        '/login/',
        '/register/'
    ]

    def process_request(self, request):
        if request.path not in self.white_list:
            user = request.session.get("username")
            ret = models.UserInfo.objects.filter(username=user)
            if not ret:
                return redirect('app01:login')
