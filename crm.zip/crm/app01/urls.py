from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^login/$', views.Login.as_view(), name='login'),
    url(r'^logout/$', views.logout, name='logout'),
    url(r'^register/$', views.Register.as_view(), name='register'),
    url(r'^home/$', views.home, name='home'),
    url(r'^customer/$',views.customer,name='customer'),
    url(r'^customer/add/$', views.CustomerAddEdit.as_view(),name='customer_add'),
    url(r'^customer/edit/(\d+)/$', views.CustomerAddEdit.as_view(),name='customer_edit'),
    url(r'^customer/del/(\d+)/$', views.customerDel, name='customer_del')
]